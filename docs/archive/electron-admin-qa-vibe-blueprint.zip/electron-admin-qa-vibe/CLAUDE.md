# CLAUDE.md
# Electron 기반 관리자웹 자율 QA 테스트 시스템

## 0. 목적

이 프로젝트는 Windows PC에 설치 가능한 Electron 기반 관리자웹 자율 QA 도구를 구현한다.

사용자는 프로그램 화면에서 아래만 입력한다.

- 대상 URL
- 로그인 ID / Password
- AI Provider: Claude Max 또는 Ollama
- 테스트 범위: Create / Read / Update / Delete
- 추가 테스트: 화면/UX, Console, Network/API, Form Validation, Table/Search/Sort/Paging, Screenshot 검토
- Safety Policy

그 후 `QA 시작` 버튼을 누르면 Playwright가 관리자웹을 자율 탐색하고 증적을 수집한 뒤 AI 분석을 거쳐 최종 `report.md`와 `issues.json`을 생성한다.

## 1. 최종 사용자 흐름

```text
프로그램 설치
  ↓
프로젝트 생성
  ↓
URL 입력
  ↓
로그인정보 입력
  ↓
Claude Max / Ollama 선택
  ↓
CRUD 테스트 범위 선택
  ↓
Safety Policy 선택
  ↓
QA 시작
  ↓
Playwright 자율탐색
  ↓
Screenshot/DOM/ARIA/Console/Network 수집
  ↓
기능검증
  ↓
AI 분석
  ↓
Issue 중복제거/심각도/우선순위
  ↓
report.md
```

## 2. 테스트 대상

지원 대상:

- localhost
- 127.0.0.1
- 사내 개발 서버
- QA 서버
- Staging
- HTTPS 개발 URL

주의: 다른 PC에서 프로그램을 실행할 때 `localhost`는 그 PC 자체를 의미한다. 다른 PC의 로컬 서버를 테스트하려면 해당 서버가 LAN에서 접근 가능해야 한다.

## 3. 권장 기술스택

### Desktop
- Electron
- React
- TypeScript
- Vite
- Tailwind CSS
- Zustand 또는 Redux Toolkit

### QA Engine
- Playwright Node API
- TypeScript
- Worker Thread 또는 Child Process

### Local DB
- SQLite

### Packaging
- electron-builder
- Windows NSIS

## 4. 전체 아키텍처

```text
Electron Renderer
  ├─ Dashboard
  ├─ 프로젝트
  ├─ QA 실행설정
  ├─ 실행 Monitor
  ├─ Issue Viewer
  ├─ Evidence Viewer
  └─ Report Viewer
       │ IPC
       ▼
Electron Main
  ├─ Credential Manager
  ├─ SQLite
  ├─ QA Orchestrator
  ├─ Playwright Manager
  ├─ AI Provider Manager
  └─ Report Manager
       │
       ├─────────────► QA Worker
       │                ├─ Explorer
       │                ├─ CRUD Test
       │                └─ Evidence
       │
       └─────────────► AI Worker
                        ├─ Claude Max
                        └─ Ollama
```

## 5. AI Provider Layer

AI Provider는 반드시 추상화한다.

```ts
interface AiProvider {
  healthCheck(): Promise<ProviderStatus>;
  analyzePage(input: PageAnalysisInput): Promise<PageAnalysisResult>;
  analyzeFunction(input: FunctionalAnalysisInput): Promise<FunctionalAnalysisResult>;
  analyzeScreenshot(input: VisualAnalysisInput): Promise<VisualAnalysisResult>;
  judgeIssues(input: IssueJudgeInput): Promise<IssueJudgeResult>;
  generateReport(input: ReportInput): Promise<string>;
}
```

구현체:

- ClaudeMaxProvider
- OllamaProvider
- 향후 AnthropicApiProvider
- 향후 OpenAIProvider

AI Provider가 실패해도 Playwright Evidence 수집은 중단하지 않는다.

## 6. Claude Max 연결

PoC:
- Claude Code CLI `claude -p`

제품화 권장:
- Claude Agent SDK

원칙:
- 사용자의 Claude 인증을 사용
- 인증정보 하드코딩 금지
- QA 프로그램에서 Claude Max를 공용 API 키처럼 내장하지 않음

## 7. Ollama 연결

기본 URL:

```text
http://localhost:11434
```

기능:
- Health Check
- 설치 모델 조회
- 모델 선택
- Structured JSON 분석
- 모델 변경

UI 예:

```text
AI Provider: Ollama
Ollama URL: http://localhost:11434
Model: qwen3.5:9b
[연결 테스트]
```

## 8. 메인 QA 설정 화면

입력 항목:

```text
프로젝트명
Target URL
Start Path
로그인 사용 여부
Username
Password

AI Provider
AI Model

CRUD:
[ ] Create
[x] Read
[ ] Update
[ ] Delete

추가:
[x] Visual QA
[x] Console
[x] Network/API
[x] Form Validation
[x] Search/Filter
[x] Table/Sort
[x] Pagination
[x] Modal
[x] Accessibility
```

## 9. Safety Policy

### SAFE
자동 허용:
- 조회
- 검색
- 상세보기
- 탭
- 정렬
- Paging
- Modal open
- Dropdown

### CAUTION
사용자가 기능 테스트를 켠 경우만:
- 등록
- 저장
- 수정
- 첨부
- 테스트 데이터 생성

### DANGEROUS
기본 차단:
- 삭제
- 사용자 차단
- 권한 변경
- 승인/반려
- 게시
- 메일/SMS/Push 발송
- 외부 연동 실행
- 대량처리

Delete는 별도 명시적 동의가 있어야 한다.

## 10. CRUD 테스트 전략

### Read
기본 자동 허용.

검증:
- 목록
- 상세
- 검색
- 필터
- 정렬
- Paging
- Tab
- Modal
- 데이터 렌더링

### Create
선택적 실행.

Form 자동 인식:
- input
- select
- textarea
- checkbox
- radio
- date
- file

테스트 데이터 Prefix:

```text
AUTO-QA-YYYYMMDD-HHMMSS-SEQ
```

### Update
기본적으로 QA가 생성한 데이터만 수정한다.

### Delete
기본 OFF.
가능하면 QA가 생성한 데이터만 삭제한다.

## 11. Functional PASS 판정

AI 감으로 판정하지 않는다.

예:

```text
저장 클릭
  ↓
POST/PUT 발생
  ↓
HTTP 2xx
  ↓
Toast/Message
  ↓
화면 또는 목록 재조회
  ↓
데이터 존재
  ↓
PASS
```

다음은 FAIL:
- HTTP 4xx/5xx
- 저장 버튼 무반응
- Loading 무한
- UI 성공인데 데이터 미존재
- Validation 누락
- JS Error로 기능 중단

## 12. Autonomous Explorer

단순 Link Crawler 금지.

상태 기반 탐색:

```text
PAGE
  ↓
ACTION DISCOVERY
  ↓
RISK CLASSIFICATION
  ↓
EXECUTION
  ↓
STATE CHANGE DETECTION
  ↓
NEW STATE
```

State Key:

```text
URL
+ Page Title
+ Main Heading
+ Visible Navigation
+ Dialog State
+ DOM Fingerprint
```

동일 State 반복 탐색 금지.

## 13. Action Discovery 대상

- a
- button
- role=button
- role=tab
- input
- select
- checkbox
- radio
- Tree Node
- Accordion
- Dropdown
- Pagination
- Modal Trigger

각 Action:

```json
{
  "type": "CLICK",
  "label": "등록",
  "risk": "CAUTION",
  "selector": "...",
  "screen": "설문관리",
  "confidence": 0.96
}
```

## 14. Evidence

각 화면마다:

- Screenshot
- DOM
- ARIA
- URL
- Title
- Console
- Network
- Action History
- Form Fields
- Visible Text
- Before/After
- Timing

저장 구조:

```text
runs/
  20260829_210000/
    screenshots/
    dom/
    aria/
    network/
    console/
    actions/
    issues.json
    report.md
```

## 15. Visual QA

Rule 기반 1차:
- viewport overflow
- horizontal scroll
- element overlap
- hidden CTA
- 비정상 empty area

AI Vision 2차:
- 주요 화면
- 이상 후보 화면
- 사용자 선택 화면

검토:
- 텍스트 잘림
- 겹침
- 여백
- 정렬
- CTA
- 표
- 모달
- 정보밀도
- 빈 상태
- 관리자 업무 흐름

Ollama 모델이 Vision 미지원이면 Visual AI 분석은 Skip하고 Rule 결과만 제공한다.

## 16. Console / Network

Console:
- error
- uncaught exception
- promise rejection
- React/Vue runtime error
- undefined/null

Network:
- 400
- 401
- 403
- 404
- 409
- 422
- 500
- timeout
- CORS
- failed request
- slow response

민감정보 마스킹:
- Authorization
- Cookie
- JWT
- Session ID
- Password

## 17. Severity

CRITICAL:
- 로그인 불가
- 권한 우회
- 개인정보 노출
- 데이터 손실
- 시스템 전체 사용 불가

HIGH:
- 핵심 CRUD 실패
- 저장 실패
- 주요 500
- 핵심 메뉴 접근 불가
- 업무 진행 차단

MEDIUM:
- Validation 문제
- 일부 기능 오동작
- 데이터 표시 오류
- 화면 깨짐
- 중요한 UX 문제

LOW:
- 정렬
- 여백
- 문구
- 아이콘
- 경미 UX

## 18. Priority

Severity와 분리.

```text
Priority Score =
Severity Weight
× Business Impact
× Frequency
× User Exposure
÷ Fix Effort
```

결과:
- P0
- P1
- P2
- P3

## 19. Issue Deduplication

같은 Root Cause가 반복되면:

```text
Issue 1개
+
Evidence N개
```

병합 기준:
- API Endpoint
- HTTP Status
- Error Signature
- Stack Message
- DOM Selector
- Action
- Screen

## 20. SQLite

권장 테이블:

```text
projects
qa_profiles
qa_runs
qa_run_pages
qa_actions
qa_evidences
qa_issues
qa_issue_evidences
ai_providers
app_settings
```

Password/Token은 SQLite에 평문 저장 금지.

Electron `safeStorage` 또는 OS Credential Store 사용.

## 21. 화면 구성

1. Dashboard
2. 프로젝트 관리
3. 신규 QA
4. 로그인 설정
5. AI Provider 설정
6. CRUD 테스트 설정
7. Safety Policy
8. QA Running Monitor
9. 탐색 화면 목록
10. Issue 목록
11. Issue 상세
12. Screenshot Viewer
13. Evidence Viewer
14. Network Viewer
15. Console Viewer
16. Report Viewer
17. 실행 History
18. Settings

## 22. 실행 Monitor

```text
QA RUNNING

현재 화면:
설문관리 > 설문등록

진행:
42 / 93 screens

현재 작업:
Form Validation

AI:
Claude Max Connected

Issues:
Critical 0
High 2
Medium 8
Low 12

[일시정지] [중단]
```

현재 Screenshot을 실시간 미리보기로 표시한다.

## 23. Browser

### Headed
PoC 및 사용자 관찰용.

### Headless
자동 회귀 테스트용.

초기 버전은 Headed 기본 권장.

## 24. Worker Isolation

```text
Electron Main
  ├─ QA Worker
  │   ├─ Playwright
  │   └─ Evidence
  ├─ AI Worker
  │   └─ Provider
  └─ Report Worker
```

Playwright/AI 오류로 Electron UI 전체가 죽으면 안 된다.

## 25. 최종 report.md

반드시 포함:

```text
실행정보
테스트환경
Executive Summary
CRUD 결과
Critical
High
Medium
Low
화면별 개선점
Console 오류
Network/API 오류
UX/UI 개선
기능 누락 후보
우선순위
권장 수정 순서
탐색 제한
미검증 기능
```

## 26. Agent

역할별 문서는 `/agents`에 둔다.

- Orchestrator
- Login
- Explorer
- Action Classifier
- CRUD Test
- Functional Reviewer
- Visual Reviewer
- Network Reviewer
- Console Reviewer
- Issue Judge
- Report Writer
- AI Provider
- Security/Safety
- Evidence
- Test Data

## 27. 개발 단계

Phase 1:
- Electron Shell
- React
- SQLite
- Project
- QA Setup

Phase 2:
- URL
- Login
- Playwright
- Screenshot
- DOM
- Console
- Network

Phase 3:
- State Graph
- Action Discovery
- Loop Prevention
- Risk Classification

Phase 4:
- Read Test
- Create
- Update
- Delete
- Test Data

Phase 5:
- Claude Max
- Ollama
- Provider Interface
- Functional Analysis
- Visual Analysis

Phase 6:
- Issue Dedup
- Severity/Priority
- report.md

Phase 7:
- electron-builder
- Windows NSIS
- Installer Test

## 28. MVP

1차 MVP:
- Electron 설치본
- URL/ID/PW 입력
- Claude Max/Ollama 선택
- Read 테스트
- 자동 로그인
- 메뉴/Link/Tab 탐색
- Screenshot
- DOM
- Console
- Network
- Issue 분석
- report.md

2차:
- Create
- Update
- Validation
- Search/Filter
- Table/Paging
- Visual QA

3차:
- Delete
- Cleanup
- Regression
- Baseline Screenshot
- CI

## 29. 비기능

- 설치 후 5분 이내 QA 시작 가능
- QA Run Crash 복구
- Password 로그 금지
- Token Masking
- Evidence 삭제 가능
- AI Provider 실패 시 Rule QA 유지
- Stop/Pause 제공
- Run별 완전 분리

## 30. 바이브코딩 규칙

개발 Agent는 항상:

1. CLAUDE.md 읽기
2. 담당 agent 문서 읽기
3. 현재 코드 분석
4. 최소 단위 구현
5. 실행
6. 테스트
7. 오류 수정
8. 변경 파일 기록
9. TODO 갱신

대규모 무계획 리팩터링 금지.

## 31. 완료 기준

설치 후 사용자가:

```text
URL 입력
ID/PW 입력
AI 선택
CRUD 선택
QA 시작
```

만 하면 된다.

종료 결과 예:

```text
탐색 84 화면

Critical 1
High 7
Medium 23
Low 18

Create PASS 7 / FAIL 1
Read PASS 52 / FAIL 3
Update PASS 5 / FAIL 2
Delete 미실행

[Report 열기]
```

`report.md`, `issues.json`, `evidence`가 자동 생성되어야 한다.
