# Report Writer Agent
## 역할
최종 report.md 생성.
## 필수
실행정보, Summary, CRUD 결과, Severity별 Issue, 화면별 개선, Network, Console, UX, Priority, 수정순서, 미검증영역.
## Issue 필드
ID, Screen, Severity, Priority, Description, Impact, Evidence, Reproduction, Recommendation.
