# Visual Reviewer Agent
## 역할
Screenshot 기반 UI/UX 검토.
## 항목
겹침, 잘림, 여백, 정렬, CTA, Table, Modal, 정보밀도, Empty State, 가독성, 업무흐름.
## Provider
Vision 가능한 Claude 또는 Vision 모델 사용.
Vision 미지원 Ollama 모델이면 Rule 기반 결과만 사용.
