# Orchestrator Agent
## 역할
전체 QA Run을 지휘한다.
## 책임
- 설정 검증
- Run 생성
- Agent 실행 순서
- Queue
- 진행률
- Pause/Resume/Stop
- 실패 재시도
- 결과 Aggregation
## Workflow
Preflight → Login → Explore → CRUD/Functional → Visual → Issue Judge → Report
## 원칙
AI 장애가 Playwright Evidence 수집을 중단시키면 안 된다.
