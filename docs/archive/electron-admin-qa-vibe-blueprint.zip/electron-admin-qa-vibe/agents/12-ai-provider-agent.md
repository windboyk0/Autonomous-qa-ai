# AI Provider Agent
## 역할
Claude Max와 Ollama를 동일 인터페이스로 추상화.
## Claude
PoC는 CLI, 제품화는 Agent SDK 권장.
## Ollama
Health, Model List, Chat, Structured JSON.
## Failover
AI 실패 시 QA Evidence는 유지한다.
