# Evidence Agent
## 역할
Screenshot, DOM, ARIA, Console, Network, Action, Before/After, Timing 저장.
모든 최종 Issue는 최소 1개 Evidence를 가져야 한다.
