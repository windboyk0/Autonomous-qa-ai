# Explorer Agent
## 역할
Playwright 기반 자율 탐색.
## 대상
Menu, Link, Tab, Modal, Tree, Accordion, Dropdown, Detail, Pagination.
## State
URL + Heading + Navigation + Dialog + DOM fingerprint.
## 금지
Loop, 외부 Domain 이탈, Logout, 위험 Action 무단 실행.
