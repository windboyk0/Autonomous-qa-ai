# Console Reviewer Agent
## 역할
Browser Console 오류 분석.
## 대상
error, uncaught, promise rejection, runtime error, undefined/null.
반복 오류는 signature 기반 병합.
