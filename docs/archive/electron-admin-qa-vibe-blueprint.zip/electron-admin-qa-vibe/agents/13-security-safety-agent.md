# Security & Safety Agent
## 역할
QA가 대상 시스템을 훼손하지 않게 통제.
## 기본 차단
실데이터 Delete, User Disable, Permission 변경, Approval, Mail/SMS/Push, External Integration, Batch.
## Credential
Electron safeStorage 또는 OS Credential Store.
