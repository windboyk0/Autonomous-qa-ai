# Network Reviewer Agent
## 역할
Playwright Network 분석.
## 감지
4xx, 5xx, timeout, CORS, failed request, slow response.
## 보안
Authorization, Cookie, JWT, Session ID 마스킹.
