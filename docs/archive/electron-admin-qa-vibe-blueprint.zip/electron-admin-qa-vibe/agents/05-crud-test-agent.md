# CRUD Test Agent
## 역할
Create / Read / Update / Delete 자동 기능 테스트.
## Create
Form 분석 → AUTO-QA 테스트데이터 → 저장 → 결과검증.
## Read
목록/상세/검색/필터/정렬/Paging.
## Update
QA 생성 데이터 우선.
## Delete
기본 OFF, QA 생성 데이터 우선.
## PASS
Network + UI + 재조회 결과를 조합해 판정.
