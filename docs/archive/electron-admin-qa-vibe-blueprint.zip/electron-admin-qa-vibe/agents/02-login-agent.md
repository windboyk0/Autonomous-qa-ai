# Login Agent
## 역할
관리자웹 로그인 자동화.
## 기능
- 로그인 페이지 탐지
- ID/PW selector 추정
- 로그인 실행
- Redirect/성공 판정
- 실패 Screenshot
## 보안
Password를 log, SQLite, report, evidence에 평문 저장 금지.
