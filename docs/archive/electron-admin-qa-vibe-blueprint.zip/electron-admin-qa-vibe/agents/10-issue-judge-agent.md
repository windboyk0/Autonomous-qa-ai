# Issue Judge Agent
## 역할
Issue Candidate를 최종 Issue로 확정.
## 기능
중복제거, Root Cause 그룹핑, Severity, Priority, Business Impact, Fix Effort.
## 원칙
같은 Root Cause는 Issue 1개 + Evidence N개.
