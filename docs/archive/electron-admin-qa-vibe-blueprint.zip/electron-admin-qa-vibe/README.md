# Electron Admin QA Vibe Blueprint

바이브코딩 시작 순서:
1. CLAUDE.md
2. agents/*.md
3. Electron Shell
4. Playwright Read-only MVP
5. Claude Max/Ollama Provider
6. CRUD 확장
7. Report 자동화
